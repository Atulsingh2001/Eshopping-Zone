//package com.shoppingzone.cart.service;
//
//import com.shoppingzone.cart.client.ProductClient;
//import com.shoppingzone.cart.dto.CartItemRequest;
//import com.shoppingzone.cart.dto.ProductDTO;
//import com.shoppingzone.cart.model.CartItem;
//import com.shoppingzone.cart.repository.CartRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class CartService {
//    @Autowired
//    private CartRepository cartRepository;
//
//    @Autowired
//    private ProductClient productClient;
//
//    public CartItem addToCart(CartItemRequest request) {
//        ProductDTO product = productClient.getProductById(request.getProductId());
//        if (product == null || product.getStock() < request.getQuantity()) {
//            return null;
//        }
//        CartItem cartItem = new CartItem();
//        cartItem.setUserId(request.getUserId());
//        cartItem.setProductId(product.getId());
//        cartItem.setQuantity(request.getQuantity());
//        return cartRepository.save(cartItem);
//    }
//
//    public List<CartItem> getCartItems(Long userId) {
//        return cartRepository.findByUserId(userId);
//    }
//
//    public String removeFromCart(Long cartItemId) {
//        if (cartRepository.existsById(cartItemId)) {
//            cartRepository.deleteById(cartItemId);
//            return "Item removed from cart!";
//        }
//        return "Item not found!";
//    }
//
//    public String clearCart(Long userId) {
//        cartRepository.deleteByUserId(userId);
//        return "Cart cleared!";
//    }
//}

package com.shoppingzone.cart.service;

import com.shoppingzone.cart.client.ProductClient;
import com.shoppingzone.cart.dto.CartItemRequest;
import com.shoppingzone.cart.dto.ProductDTO;
import com.shoppingzone.cart.model.CartItem;
import com.shoppingzone.cart.repository.CartRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {

    private final CartRepository cartRepository;
    private final ProductClient productClient;

    public CartService(CartRepository cartRepository, ProductClient productClient) {
        this.cartRepository = cartRepository;
        this.productClient = productClient;
    }

    public CartItem addToCart(CartItemRequest request) {
        ProductDTO product = productClient.getProductById(request.getProductId());
        if (product == null || product.getStock() < request.getQuantity()) {
            return null;
        }
        CartItem cartItem = new CartItem();
        cartItem.setUserId(request.getUserId());
        cartItem.setProductId(product.getId());
        cartItem.setQuantity(request.getQuantity());
        return cartRepository.save(cartItem);
    }

    public List<CartItem> getCartItems(Long userId) {
        return cartRepository.findByUserId(userId);
    }

    public String removeFromCart(Long cartItemId) {
        if (cartRepository.existsById(cartItemId)) {
            cartRepository.deleteById(cartItemId);
            return "Item removed from cart!";
        }
        return "Item not found!";
    }

    public String clearCart(Long userId) {
        cartRepository.deleteByUserId(userId);
        return "Cart cleared!";
    }
}