//package com.shoppingzone.cart.dto;
//
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//
////
////@Getter
//////@Setter
////@NoArgsConstructor
////@AllArgsConstructor
//public class ProductDTO {
//    public ProductDTO(Long id, String name, double price, int stock) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.price = price;
//		this.stock = stock;
//	}
//	public ProductDTO() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private Long id;
//    private String name;
//    private double price;
//    private int stock;
//	public Long getId() {
//		return id;
//	}
//	public void setId(Long id) {
//		this.id = id;
//	}
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
//	public double getPrice() {
//		return price;
//	}
//	public void setPrice(double price) {
//		this.price = price;
//	}
//	public int getStock() {
//		return stock;
//	}
//	public void setStock(int stock) {
//		this.stock = stock;
//	}
//	@Override
//	public String toString() {
//		return "ProductDTO [id=" + id + ", name=" + name + ", price=" + price + ", stock=" + stock + "]";
//	}
//	
//}


package com.shoppingzone.cart.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDTO {
    private Long id;
    private String name;
    private double price;
    private int stock;
}