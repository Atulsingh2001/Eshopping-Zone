//package com.shoppingzone.product;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.mockito.Mockito.doNothing;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import com.shoppingzone.product.model.Product;
//import com.shoppingzone.product.repository.ProductRepository;
//import com.shoppingzone.product.service.ProductService;
//
//class ProductTesting {
//
//    @Mock
//    private ProductRepository productRepository;
//
//    @InjectMocks
//    private ProductService productService;
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    void getAllProducts_shouldReturnProductList() {
//        List<Product> products = Arrays.asList(new Product(), new Product());
//        when(productRepository.findAll()).thenReturn(products);
//
//        List<Product> result = productService.getAllProducts();
//
//        assertEquals(2, result.size());
//        verify(productRepository).findAll();
//    }
//
//    @Test
//    void getProductById_shouldReturnProduct() {
//        Product product = new Product();
//        product.setId(1L);
//        when(productRepository.findById(1L)).thenReturn(Optional.of(product));
//
//        Optional<Product> result = productService.getProductById(1L);
//
//        assertTrue(result.isPresent());
//        assertEquals(1L, result.get().getId());
//    }
//
//    @Test
//    void addProduct_shouldSaveProduct() {
//        Product product = new Product();
//        when(productRepository.save(product)).thenReturn(product);
//
//        Product result = productService.addProduct(product);
//
//        assertNotNull(result);
//        verify(productRepository).save(product);
//    }
//
//    @Test
//    void updateProduct_shouldCheckExistence() {
//        Product product = new Product();
//        product.setId(1L);
//        when(productRepository.existsById(1L)).thenReturn(true);
//
//        productService.updateProduct(1L, product);
//
//        verify(productRepository).existsById(1L);
//        // If your service does not call save, do not verify save
//    }
//
//    @Test
//    void deleteProduct_shouldCheckExistence() {
//        when(productRepository.existsById(1L)).thenReturn(true);
//
//        productService.deleteProduct(1L);
//
//        verify(productRepository).existsById(1L);
//        // If your service does not call deleteById, do not verify it
//    }
//}