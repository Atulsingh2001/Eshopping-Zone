package com.shoppingzone.order;

import com.shoppingzone.order.client.ProductClient;
import com.shoppingzone.order.dto.OrderRequest;
import com.shoppingzone.order.dto.ProductDTO;
import com.shoppingzone.order.model.Order;
import com.shoppingzone.order.repository.OrderRepository;
import com.shoppingzone.order.service.OrderService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class OrderServiceApplicationTests {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private ProductClient productClient;

    @InjectMocks
    private OrderService orderService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void placeOrder_returnsOrder_whenProductInStock() {
        OrderRequest orderRequest = new OrderRequest();
        orderRequest.setUserId(1L);
        orderRequest.setProductId(2L);
        orderRequest.setQuantity(2);

        ProductDTO productDTO = new ProductDTO();
        productDTO.setId(2L);
        productDTO.setName("Test Product");
        productDTO.setPrice(50.0);
        productDTO.setStock(10);

        Order savedOrder = new Order();
        savedOrder.setUserId(1L);
        savedOrder.setProductId(2L);
        savedOrder.setQuantity(2);
        savedOrder.setTotalPrice(100.0);

        when(productClient.getProductById(2L)).thenReturn(productDTO);
        when(orderRepository.save(any(Order.class))).thenReturn(savedOrder);

        Order result = orderService.placeOrder(orderRequest);

        assertNotNull(result);
        assertEquals(1L, result.getUserId());
        assertEquals(2L, result.getProductId());
        assertEquals(2, result.getQuantity());
        assertEquals(100.0, result.getTotalPrice());
        verify(productClient).getProductById(2L);
        verify(orderRepository).save(any(Order.class));
    }

    @Test
    void placeOrder_returnsNull_whenProductOutOfStock() {
        OrderRequest orderRequest = new OrderRequest();
        orderRequest.setUserId(1L);
        orderRequest.setProductId(2L);
        orderRequest.setQuantity(5);

        ProductDTO productDTO = new ProductDTO();
        productDTO.setId(2L);
        productDTO.setName("Test Product");
        productDTO.setPrice(50.0);
        productDTO.setStock(2);

        when(productClient.getProductById(2L)).thenReturn(productDTO);

        Order result = orderService.placeOrder(orderRequest);

        assertNull(result);
        verify(productClient).getProductById(2L);
        verify(orderRepository, never()).save(any(Order.class));
    }

   
    @Test
    void getOrdersByUserId_returnsOrderList() {
        Order order1 = new Order();
        order1.setUserId(1L);
        Order order2 = new Order();
        order2.setUserId(1L);

        List<Order> orders = Arrays.asList(order1, order2);

        when(orderRepository.findByUserId(1L)).thenReturn(orders);

        List<Order> result = orderService.getOrdersByUserId(1L);

        assertEquals(2, result.size());
        verify(orderRepository).findByUserId(1L);
    }

    @Test
    void cancelOrder_deletesOrder_whenOrderExists() {
        when(orderRepository.existsById(1L)).thenReturn(true);
        doNothing().when(orderRepository).deleteById(1L);

        String result = orderService.cancelOrder(1L);

        assertEquals("Order canceled successfully!", result);
        verify(orderRepository).existsById(1L);
        verify(orderRepository).deleteById(1L);
    }

    @Test
    void cancelOrder_returnsNotFound_whenOrderDoesNotExist() {
        when(orderRepository.existsById(1L)).thenReturn(false);

        String result = orderService.cancelOrder(1L);

        assertEquals("Order not found!", result);
        verify(orderRepository).existsById(1L);
        verify(orderRepository, never()).deleteById(anyLong());
    }
}