package com.shoppingzone.order.service;

import com.shoppingzone.order.client.ProductClient;
import com.shoppingzone.order.dto.OrderRequest;
import com.shoppingzone.order.dto.ProductDTO;
import com.shoppingzone.order.model.Order;
import com.shoppingzone.order.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductClient productClient;

    public Order placeOrder(OrderRequest orderRequest) {
        ProductDTO product = productClient.getProductById(orderRequest.getProductId());
        System.out.println(product.getName());
        if (product == null || product.getStock() < orderRequest.getQuantity()) {
            return null;
        }

        Order order = new Order();
        order.setUserId(orderRequest.getUserId());
        order.setProductId(product.getId());
        order.setQuantity(orderRequest.getQuantity());
        order.setTotalPrice(product.getPrice() * orderRequest.getQuantity());

        return orderRepository.save(order);
    }

    public List<Order> getOrdersByUserId(Long userId) {
        return orderRepository.findByUserId(userId);
    }

    public String cancelOrder(Long orderId) {
        if (orderRepository.existsById(orderId)) {
            orderRepository.deleteById(orderId);
            return "Order canceled successfully!";
        }
        return "Order not found!";
    }
}