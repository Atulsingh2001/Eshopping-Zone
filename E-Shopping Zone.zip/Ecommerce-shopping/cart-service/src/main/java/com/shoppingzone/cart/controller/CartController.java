package com.shoppingzone.cart.controller;

import com.shoppingzone.cart.dto.CartItemRequest;
import com.shoppingzone.cart.model.CartItem;
import com.shoppingzone.cart.service.CartService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @PostMapping("/addItems")
    public ResponseEntity<CartItem> addToCart(@RequestBody CartItemRequest request) {
        CartItem cartItem = cartService.addToCart(request);
        if (cartItem == null) {
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok(cartItem);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<List<CartItem>> getCartItems(@PathVariable Long userId) {
        return ResponseEntity.ok(cartService.getCartItems(userId));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> removeFromCart(@PathVariable Long id) {
        return ResponseEntity.ok(cartService.removeFromCart(id));
    }

    @DeleteMapping("/clear/{userId}")
    public ResponseEntity<String> clearCart(@PathVariable Long userId) {
        return ResponseEntity.ok(cartService.clearCart(userId));
    }
}


//package com.shoppingzone.cart.controller;
//
//import com.shoppingzone.cart.dto.CartItemRequest;
//import com.shoppingzone.cart.model.CartItem;
//import com.shoppingzone.cart.service.CartService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/cart")
//public class CartController {
//    @Autowired
//    private CartService cartService;
//
//    @PostMapping
//    public ResponseEntity<CartItem> addToCart(@RequestBody CartItemRequest request) {
//        CartItem cartItem = cartService.addToCart(request);
//        if (cartItem == null) {
//            return ResponseEntity.badRequest().build();
//        }
//        return ResponseEntity.ok(cartItem);
//    }
//
//    @GetMapping("/{userId}")
//    public ResponseEntity<List<CartItem>> getCartItems(@PathVariable Long userId) {
//        return ResponseEntity.ok(cartService.getCartItems(userId));
//    }
//
//    @DeleteMapping("/{id}")
//    public ResponseEntity<String> removeFromCart(@PathVariable Long id) {
//        return ResponseEntity.ok(cartService.removeFromCart(id));
//    }
//
//    @DeleteMapping("/clear/{userId}")
//    public ResponseEntity<String> clearCart(@PathVariable Long userId) {
//        return ResponseEntity.ok(cartService.clearCart(userId));
//    }
//}