//package com.shoppingzone.cart.repository;
//
//import com.shoppingzone.cart.model.CartItem;
//import org.springframework.data.jpa.repository.JpaRepository;
//import java.util.List;
//
//public interface CartRepository extends JpaRepository<CartItem, Long> {
//    List<CartItem> findByUserId(Long userId);
//    void deleteByUserId(Long userId);
//}


package com.shoppingzone.cart.repository;

import com.shoppingzone.cart.model.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CartRepository extends JpaRepository<CartItem, Long> {
    List<CartItem> findByUserId(Long userId);
    void deleteByUserId(Long userId);
}