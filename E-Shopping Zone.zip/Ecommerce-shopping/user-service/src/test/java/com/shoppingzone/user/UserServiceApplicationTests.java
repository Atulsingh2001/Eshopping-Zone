package com.shoppingzone.user;



import com.shoppingzone.user.model.User;
import com.shoppingzone.user.repository.UserRepository;
import com.shoppingzone.user.security.JwtUtil;
import com.shoppingzone.user.service.AuthService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceApplicationTests {

    @InjectMocks
    private AuthService authService;

    @Mock
    private UserRepository userRepository;
    @Mock
    private JwtUtil jwtUtil;

    @Spy
    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void registerUser_shouldEncryptPasswordAndSaveUser() {
        User user = new User();
        user.setUsername("test");
        user.setPassword("password");
        user.setRole(null);

        when(userRepository.save(any(User.class))).thenReturn(user);

        String result = authService.registerUser(user);

        assertEquals("User registered successfully!", result);
        verify(userRepository).save(any(User.class));
        assertEquals("USER", user.getRole());
    }

    @Test
    void loginUser_shouldReturnTokenOnValidCredentials() {
        User user = new User();
        user.setUsername("test");
        user.setPassword(passwordEncoder.encode("password"));
        user.setRole("USER");

        when(userRepository.findByUsername("test")).thenReturn(Optional.of(user));
        when(jwtUtil.generateToken("test", "USER")).thenReturn("mockedToken");

        String token = authService.loginUser("test", "password");

        assertEquals("mockedToken", token);
    }

    @Test
    void loginUser_shouldThrowExceptionOnInvalidCredentials() {
        when(userRepository.findByUsername("test")).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> authService.loginUser("test", "wrong"));
    }
}
