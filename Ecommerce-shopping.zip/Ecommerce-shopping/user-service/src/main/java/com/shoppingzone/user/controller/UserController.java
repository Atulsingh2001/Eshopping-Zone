package com.shoppingzone.user.controller;

import com.shoppingzone.user.model.User;
import com.shoppingzone.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
//
//    @PostMapping("/register")
//    public ResponseEntity<String> register(@RequestBody User user) {
//        return ResponseEntity.ok(userService.registerUser(user));
//    }

    @PostMapping("/authenticate")
    public ResponseEntity<String> authenticate(@RequestBody User user) {
        String token = userService.authenticate(user.getUsername(), user.getPassword());
        if (token != null && !token.equals("Invalid credentials")) {
            return ResponseEntity.ok(token);
        }
        return ResponseEntity.status(401).body("Invalid credentials");
    }
}