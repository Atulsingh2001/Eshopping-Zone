package com.ioc.coupling;

public interface UserDataProvider {
    String getUserDetails();
}
