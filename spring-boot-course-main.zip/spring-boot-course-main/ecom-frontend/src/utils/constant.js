import bannerImageOne from "../assets/sliders/s_1.webp";
import bannerImageTwo from "../assets/sliders/s_2.webp";
import bannerImageThree from "../assets/sliders/s_3.webp";

export {
    bannerImageOne,
    bannerImageTwo,
    bannerImageThree
}